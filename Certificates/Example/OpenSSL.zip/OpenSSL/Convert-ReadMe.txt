For more details see: https://github.com/aws-samples/iot-dotnet-publisher-consumer
also for download of dotnet and dotnet core sample projects

- Start OpenSSL.exe -> run as admin

- openssl> pkcs12 -export -in f489713a83-certificate.pem.crt -inkey f489713a83-private.pem.key -out devicecertificateinpfxformat.pfx -certfile Amazone_Root_CA_1.pem